
import DataFetcherWrapper from "@/components/common/DataFetcherWrapper";
import TransactionForm from "../components/transaction/TransactionForm";
import { FilterSection } from "@/components/transaction/FilterSection";
import { SummarySection } from "@/components/transaction/SummarySection";
import { TransactionTable } from "@/components/transaction/TransactionTable";
import { ToastContainer } from "react-toastify";

function TransactionPage() {
  return (
    <>
      <div className="flex gap-5">
        <div className="flex-1 overflow-x-auto bg-white border rounded-xl w-3/4 p-5">
          <h2 className="text-2xl font-semibold mb-4">Riwayat Transaksi</h2>
          <FilterSection />
          <SummarySection totalPemasukan={10000000} totalPengeluaran={2560000} />

          <DataFetcherWrapper endpoint="transactions">
            {({ data: transactions }) => (
              <TransactionTable transactions={transactions} />
            )}
          </DataFetcherWrapper>
        </div>

        <div className="w-1/4 sticky top-0">
          <div className="bg-white rounded-xl border p-5">
            <h3 className="font-bold text-2xl mb-3">Add New Transaction</h3>
            <DataFetcherWrapper endpoint="transactions">
              {({ refresh }) => (
                <TransactionForm onTransactionAdded={refresh} />
              )}
            </DataFetcherWrapper>
          </div>
        </div>
      </div>

      <ToastContainer />
    </>
  );
}

export default TransactionPage;
