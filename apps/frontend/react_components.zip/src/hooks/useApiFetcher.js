
import { useState, useEffect } from "react";
import { fetching } from "@/utils/fetching";

export const useApiFetcher = (endpoint) => {
  const [data, setData] = useState([]);
  const [pagination, setPagination] = useState({});
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);
  const [showPagination, setShowPagination] = useState(false);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const response = await fetching(`${endpoint}?page=${page}`);
      const { data } = response;

      setData(data.data || []);
      setPagination({
        current_page: data.current_page,
        last_page: data.last_page,
        prev_page_url: data.prev_page_url,
        next_page_url: data.next_page_url,
      });

      setShowPagination(data.total > data.per_page);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [page, refreshKey, endpoint]);

  const refresh = () => setRefreshKey((prev) => prev + 1);

  return { data, pagination, page, setPage, isLoading, showPagination, refresh };
};
